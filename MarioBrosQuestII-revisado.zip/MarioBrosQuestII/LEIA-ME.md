# Super Mario — Quest II — versão revisada

## Abrir
Extraia o ZIP inteiro. No Godot 4.7.x, importe `MarioBrosQuestII/project.godot`, aguarde as imagens serem importadas e pressione F5. Projeto validado com Godot 4.7.2, renderizador Compatibility.

## O que foi corrigido nesta revisão
- Mario mais lento: velocidade máxima de 150 para 100, redução de 33%. A aceleração foi suavizada de 10 para 3,5, com frenagem mais firme ao soltar o botão.
- A Fase 1 agora reutiliza a cena original enviada: mesmo terreno, morros, arbustos, nuvens, canos, plataformas de tijolos, blocos de bônus, escadarias, bandeira e castelo. Um dos buracos foi estreitado de 64 para 48 pixels para acomodar o movimento mais lento. A saída subterrânea ficou desativada nesta campanha para preservar a progressão das quatro fases.
- Fases 2, 3 e 4 reconstruídas no mesmo estilo da fase original, com mapas próprios e os mesmos elementos visuais. O zoom voltou a 2,75, como no arquivo enviado.
- Salto ajustado para alcançar os canos da fase original. A câmera acompanha as subidas mais altas e retorna ao enquadramento do castelo no encerramento.
- Menu reconstruído com contêineres de layout. As instruções e o botão Começar ocupam espaços separados e não se sobrepõem.
- O botão Bola de fogo e o atalho F continuam disponíveis desde o início.

## Controles
- A/D ou setas esquerda/direita: mover.
- Espaço ou seta para cima: pular. Segure para o salto completo; solte cedo para saltar menos.
- F, Shift ou botão Bola de fogo: disparar, mesmo com Mario pequeno.
- R ou Reiniciar: reiniciar a fase atual.
- Esc ou Menu: voltar à tela inicial.
- Enter aciona Começar ou Próxima fase quando o botão está selecionado.

Tiros têm intervalo de 0,35 segundo e duração de até 2,5 segundos. Acerte Goombas e Koopas com os tiros ou pule sobre eles, seguindo a lógica do tutorial.

## Como cada fase termina
1. **Campos verdes:** cenário original adaptado. Alcance a bandeira e assista à entrada no castelo. Moedas são opcionais.
2. **Vale das moedas:** colete pelo menos 8 moedas da fase e alcance a bandeira. Existem 16 moedas pelo mapa, além dos blocos de bônus.
3. **Caminho dos Koopas:** atravesse o percurso com quatro buracos, canos e escadaria; alcance a bandeira. Não é necessário derrotar todos os inimigos.
4. **Estrada do castelo:** colete pelo menos 10 moedas da fase e alcance a bandeira. Existem 22 moedas pelo mapa, além dos blocos de bônus. Entrar no castelo encerra a campanha e mostra a vitória.

O objetivo aparece no alto da tela. Nas três primeiras fases, use Próxima fase após a animação. Na quarta, o botão leva ao menu. É possível voltar pelo percurso para buscar moedas.

Morrer ou reiniciar restaura a fase e os pontos/moedas do início daquela fase. O progresso das fases já concluídas permanece durante a partida. Começar uma nova aventura zera tudo. Não há limite de tentativas ou salvamento ao fechar o jogo.

## Organização
- `Scenes/menu.tscn` e `Scripts/menu.gd`: tela inicial.
- `Scenes/Levels/fase_1.tscn` a `fase_4.tscn`: as quatro fases, editáveis como cenas do Godot. Terreno montado com o TileMap do tutorial.
- `Scripts/level_manager.gd`: objetivos, contagem e progressão.
- `Scenes/quest_ui.tscn` e `Scripts/ui.gd`: painel, botões e tela de conclusão.
- `Scripts/player.gd`: lógica original de movimento, salto, transformações e bandeira, com os ajustes descritos acima.
- Player, Goomba, Koopa, tijolos, caixas, moedas, cogumelos, flores, tiros e bandeira reutilizam as cenas e assets enviados.
- `Scenes/main.tscn` e `underground.tscn`: referências originais, fora da sequência da campanha.

## Materiais consultados
Foram consultadas as seis partes dos PDFs da professora, inclusive exemplos de código nas imagens: organização da cena e camadas de colisão (I), Player e animações (II–III), Goomba/Koopa e herança de Enemy (IV–V), colisões, pontos e morte (VI).

O pacote enemies(1).zip foi reaproveitado. Mario(2).zip foi inspecionado; a base já continha os sprites separados equivalentes. A música e folhas de sprites redundantes não foram adicionadas. Os PDFs não são necessários para executar o jogo e não foram duplicados no ZIP. Personagens e assets pertencem aos respectivos autores; este projeto é destinado à atividade acadêmica.

## Testes da revisão
- Fluxo das quatro fases: objetivos, bandeira, animação, castelo, vitória, retorno ao menu e reinício após morte.
- Todos os 14 buracos atravessados com entrada simulada e física real na nova velocidade.
- Cano mais alto de cada fase atravessado com a nova configuração.
- Tiro atingindo Goomba, pontuação, intervalo de disparo e queda com Mario grande.
- Imagens renderizadas pelo Godot revisadas: menu, trechos das quatro fases e escadaria alta da Fase 1.
- Verificação geométrica do menu: instruções terminam em y=329; botão começa em y=404, com 75 pixels de distância.
- A câmera foi verificada na escadaria para manter o Mario visível abaixo do painel.

Os testes de progressão posicionam o personagem e coletam moedas por chamadas controladas; não representam uma partida manual completa. Os testes de saltos e projéteis usam a física real. A revisão visual foi feita em capturas renderizadas pelo próprio Godot.

Após importar o projeto, os testes reproduzíveis podem ser executados na pasta do projeto:

    godot --headless --path . res://Tests/test_campaign.tscn
    godot --headless --path . res://Tests/test_physics.tscn

Ambos devem terminar com `FAILURES: 0`. Resultados em `Tests/Resultados/`.
