extends Node
class_name LevelManager

@export var ui: UI
@export var player: Player
@export var phase: int = 1
@export var phase_title: String = "Campos verdes"
@export var required_coins: int = 0
@export var sky: Color = Color("54a6ed")
var points: int = 0
var coins: int = 0
var level_coins: int = 0
var completed = false

func _ready():
	RenderingServer.set_default_clear_color(sky)
	points = SceneData.points
	coins = SceneData.coins
	ui.set_score(points)
	ui.set_coins(coins)
	ui.set_objective(phase, phase_title, required_coins, level_coins)
	player.castle_entered.connect(finish_level)
	player.points_scored.connect(on_points_scored)
	# Extra bindings retain the original A/D, Space and Shift controls.
	for pair in [["left", KEY_LEFT], ["right", KEY_RIGHT], ["jump", KEY_UP], ["shoot", KEY_F]]:
		var event = InputEventKey.new()
		event.physical_keycode = pair[1]
		if not InputMap.action_has_event(pair[0], event):
			InputMap.action_add_event(pair[0], event)

func on_points_scored(amount: int):
	points += amount
	ui.set_score(points)

func on_coin_collected():
	if completed:
		return
	coins += 1
	level_coins += 1
	on_points_scored(50)
	ui.set_coins(coins)
	ui.set_objective(phase, phase_title, required_coins, level_coins)

func can_finish() -> bool:
	return not completed and level_coins >= required_coins

func finish_level():
	if completed:
		return
	completed = true
	SceneData.points = points
	SceneData.coins = coins
	SceneData.return_point = Vector2.ZERO
	ui.on_finish()

func next_level():
	if phase < 4:
		get_tree().change_scene_to_file("res://Scenes/Levels/fase_%d.tscn" % (phase + 1))
	else:
		get_tree().change_scene_to_file("res://Scenes/menu.tscn")
