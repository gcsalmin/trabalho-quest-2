extends Control

func text_line(value: String, font_size: int, tint: Color = Color.WHITE) -> Label:
	var item = Label.new()
	item.text = value
	item.add_theme_font_size_override("font_size", font_size)
	item.modulate = tint
	return item

func scenery(texture: String, pos: Vector2, factor: float = 3.0):
	var sprite = Sprite2D.new()
	sprite.texture = load("res://Assets/Sprites/" + texture)
	sprite.position = pos
	sprite.scale = Vector2(factor, factor)
	add_child(sprite)

func _ready():
	RenderingServer.set_default_clear_color(Color("2981bb"))
	for i in range(21):
		scenery("GroundBlock.png", Vector2(i * 48 + 24, 516))
	scenery("Hill1.png", Vector2(770, 468))
	scenery("Bush2.png", Vector2(614, 468))
	scenery("Cloud2.png", Vector2(764, 74))
	scenery("Cloud1.png", Vector2(894, 152))
	scenery("Castle.png", Vector2(810, 372))
	scenery("Mario_Small_Idle.png", Vector2(665, 468))
	var panel = PanelContainer.new()
	panel.name = "MenuPanel"
	panel.position = Vector2(36, 28)
	panel.size = Vector2(554, 446)
	var style = StyleBoxFlat.new()
	style.bg_color = Color("12233bf5")
	style.border_color = Color("f7c660")
	style.set_border_width_all(2)
	style.set_corner_radius_all(8)
	style.content_margin_left = 28
	style.content_margin_right = 28
	style.content_margin_top = 22
	style.content_margin_bottom = 22
	panel.add_theme_stylebox_override("panel", style)
	add_child(panel)
	var column = VBoxContainer.new()
	column.name = "Column"
	column.add_theme_constant_override("separation", 14)
	panel.add_child(column)
	var title = text_line("SUPER MARIO", 36)
	title.add_theme_font_override("font", preload("res://Assets/Fonts/font.ttf"))
	column.add_child(title)
	column.add_child(text_line("QUEST II  /  QUATRO FASES", 17, Color("f7c660")))
	var intro = VBoxContainer.new()
	intro.add_theme_constant_override("separation", 2)
	intro.add_child(text_line("Cumpra o objetivo de cada fase", 18))
	intro.add_child(text_line("e chegue à bandeira para continuar.", 18))
	column.add_child(intro)
	var controls = GridContainer.new()
	controls.name = "Controls"
	controls.columns = 2
	controls.add_theme_constant_override("h_separation", 24)
	controls.add_theme_constant_override("v_separation", 6)
	for pair in [["A / D ou ← / →", "Mover"], ["Espaço ou ↑", "Pular"], ["F / Shift ou botão", "Bola de fogo"], ["R / Esc", "Reiniciar / Menu"]]:
		controls.add_child(text_line(pair[0], 17, Color("f7c660")))
		controls.add_child(text_line(pair[1], 17))
	column.add_child(controls)
	var spacer = Control.new()
	spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	spacer.custom_minimum_size.y = 8
	column.add_child(spacer)
	var start = Button.new()
	start.name = "StartButton"
	start.text = "COMEÇAR A AVENTURA"
	start.custom_minimum_size = Vector2(0, 48)
	start.add_theme_font_size_override("font_size", 18)
	var normal = StyleBoxFlat.new()
	normal.bg_color = Color("f7c660")
	normal.set_corner_radius_all(5)
	start.add_theme_stylebox_override("normal", normal)
	var hover = normal.duplicate()
	hover.bg_color = Color("ffe29b")
	start.add_theme_stylebox_override("hover", hover)
	start.add_theme_color_override("font_color", Color("12233b"))
	start.add_theme_color_override("font_hover_color", Color("12233b"))
	start.add_theme_color_override("font_focus_color", Color("12233b"))
	start.pressed.connect(SceneData.start)
	column.add_child(start)
	start.grab_focus()
