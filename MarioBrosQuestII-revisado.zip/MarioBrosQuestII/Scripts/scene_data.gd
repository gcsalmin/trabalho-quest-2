extends Node

var return_point: Vector2
var player_mode: Player.PlayerMode
var points: int = 0
var coins: int = 0

func reset_run():
	return_point = Vector2.ZERO
	player_mode = Player.PlayerMode.SMALL
	points = 0
	coins = 0

func start():
	reset_run()
	get_tree().change_scene_to_file("res://Scenes/Levels/fase_1.tscn")
