extends Area2D

func _on_body_entered(body):
	if body is Player:
		var manager = get_tree().get_first_node_in_group("level_manager")
		if manager.can_finish():
			body.on_pole_hit()
		else:
			manager.ui.show_hint("Faltam moedas! Volte e colete o objetivo.")
