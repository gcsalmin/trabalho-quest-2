extends CanvasLayer
class_name UI

var score_label: Label
var coins_label: Label
var objective: Label
var hint: Label
var finish_panel: PanelContainer

func label_at(text: String, pos: Vector2, size: int = 20) -> Label:
	var l = Label.new()
	l.text = text
	l.position = pos
	l.add_theme_font_size_override("font_size", size)
	add_child(l)
	return l

func button_at(text: String, pos: Vector2, callback: Callable) -> Button:
	var b = Button.new()
	b.text = text
	b.position = pos
	b.size = Vector2(156, 36)
	b.focus_mode = Control.FOCUS_NONE
	b.pressed.connect(callback)
	add_child(b)
	return b

func _ready():
	# This HUD is also compatible with the original tutorial UI scene.
	for child in get_children():
		child.queue_free()
	var top = ColorRect.new()
	top.color = Color(0.025, 0.055, 0.12, 0.94)
	top.size = Vector2(960, 76)
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(top)
	score_label = label_at("PONTOS  0", Vector2(26, 12))
	coins_label = label_at("MOEDAS  0", Vector2(260, 12))
	objective = label_at("", Vector2(26, 44), 17)
	hint = label_at("", Vector2(26, 470), 19)
	button_at("Bola de fogo [F]", Vector2(784, 476), func():
		var manager = get_tree().get_first_node_in_group("level_manager")
		if is_instance_valid(manager.player):
			manager.player.shoot())
	button_at("Reiniciar [R]", Vector2(602, 10), restart)
	button_at("Menu [Esc]", Vector2(782, 10), menu)

func set_score(value: int):
	score_label.text = "PONTOS  %05d" % value

func set_coins(value: int):
	coins_label.text = "MOEDAS  %02d" % value

func set_objective(phase: int, title: String, required: int, current: int):
	var goal = "Chegue à bandeira" if required == 0 else "Moedas %d/%d + bandeira" % [current, required]
	objective.text = "FASE %d/4  •  %s  |  %s" % [phase, title, goal]

func show_hint(message: String):
	hint.text = message
	get_tree().create_timer(3).timeout.connect(func(): hint.text = "")

func restart():
	get_tree().reload_current_scene()

func menu():
	get_tree().change_scene_to_file("res://Scenes/menu.tscn")

func _unhandled_key_input(event):
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_R:
			restart()
		elif event.keycode == KEY_ESCAPE:
			menu()

func on_finish():
	var manager = get_tree().get_first_node_in_group("level_manager")
	finish_panel = PanelContainer.new()
	finish_panel.position = Vector2(240, 150)
	finish_panel.size = Vector2(480, 270)
	add_child(finish_panel)
	var box = VBoxContainer.new()
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_theme_constant_override("separation", 22)
	finish_panel.add_child(box)
	var title = Label.new()
	title.text = "QUEST II CONCLUÍDA!" if manager.phase == 4 else "FASE %d CONCLUÍDA!" % manager.phase
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 27)
	box.add_child(title)
	var info = Label.new()
	info.text = "Quatro fases vencidas. Parabéns!" if manager.phase == 4 else "Objetivo cumprido. Vamos continuar?"
	info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(info)
	var next = Button.new()
	next.text = "Voltar ao menu" if manager.phase == 4 else "Próxima fase →"
	next.custom_minimum_size.y = 48
	next.pressed.connect(manager.next_level)
	box.add_child(next)
	next.grab_focus()
