extends Node
var failures = 0
func check(ok: bool, message: String):
	if not ok:
		failures += 1
		push_error(message)
	else:
		print("PASS: " + message)
func _ready():
	reparent.call_deferred(get_tree().root)
	call_deferred("run")
func run():
	get_tree().change_scene_to_file("res://Scenes/menu.tscn")
	await get_tree().process_frame
	await get_tree().process_frame
	check(get_tree().current_scene.name == "Menu", "Menu loads")
	get_tree().root.get_node("SceneData").start()
	for phase in range(1,5):
		await get_tree().process_frame
		await get_tree().process_frame
		await get_tree().create_timer(0.1).timeout
		var manager = get_tree().get_first_node_in_group("level_manager")
		check(manager.phase == phase, "Phase %d loads via campaign" % phase)
		var player = manager.player
		check(player.is_physics_processing(), "Player active")
		var before = get_tree().current_scene.get_child_count()
		player.shoot()
		check(get_tree().current_scene.get_child_count() == before + 1, "Fireball spawned")
		player.shoot()
		check(get_tree().current_scene.get_child_count() == before + 1, "Fire cooldown")
		if manager.required_coins > 0:
			get_tree().current_scene.get_node("Flag")._on_body_entered(player)
			check(not player.finishing, "Flag locked before coins")
		for child in get_tree().current_scene.find_children("*", "Area2D", true, false):
			if child.has_method("_on_body_entered") and child.name.begins_with("Coin"):
				child._on_body_entered(player)
		check(manager.can_finish(), "Coin objective achievable")
		player.global_position = get_tree().current_scene.get_node("Flag").global_position + Vector2(-12, 0)
		get_tree().current_scene.get_node("Flag")._on_body_entered(player)
		await get_tree().create_timer(6).timeout
		check(manager.completed, "Flag animation and castle completion")
		check(is_instance_valid(manager.ui.finish_panel), "Completion screen")
		manager.next_level()
	await get_tree().process_frame
	await get_tree().process_frame
	check(get_tree().current_scene.name == "Menu", "Victory returns to menu")
	get_tree().root.get_node("SceneData").start()
	await get_tree().process_frame
	await get_tree().process_frame
	var manager = get_tree().get_first_node_in_group("level_manager")
	check(manager.points == 0 and manager.coins == 0, "New game resets score")
	manager.player.die()
	await get_tree().create_timer(2).timeout
	manager = get_tree().get_first_node_in_group("level_manager")
	check(manager.phase == 1 and not manager.player.is_dead, "Death restarts phase")
	print("FAILURES: %d" % failures)
	get_tree().quit(1 if failures else 0)
