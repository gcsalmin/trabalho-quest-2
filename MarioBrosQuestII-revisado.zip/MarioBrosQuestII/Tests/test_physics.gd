extends Node
var failures = 0
func check(ok: bool, message: String):
	if not ok:
		failures += 1
		push_error(message)
	else:
		print("PASS: " + message)
func _ready():
	reparent.call_deferred(get_tree().root)
	call_deferred("run")
func wait(seconds: float):
	await get_tree().create_timer(seconds).timeout
func run():
	var gaps = [[[688,736,80],[1152,1200,80],[2480,2528,16]], [[608,640,80],[1248,1296,80],[1808,1840,80]], [[400,448,80],[864,896,80],[1328,1376,80],[1760,1808,80]], [[496,528,80],[1072,1120,80],[1664,1712,80],[2080,2112,80]]]
	for phase in range(1,5):
		get_tree().change_scene_to_file("res://Scenes/Levels/fase_%d.tscn" % phase)
		await get_tree().process_frame
		await get_tree().process_frame
		var manager = get_tree().get_first_node_in_group("level_manager")
		var player = manager.player
		for child in get_tree().current_scene.find_children("*", "Area2D", true, false):
			if child is Enemy:
				child.queue_free()
		await get_tree().physics_frame
		check(player.speed == 100.0 and player.run_speed_damping == 3.5, "Phase %d slower speed and acceleration" % phase)
		for gap in gaps[phase - 1]:
			player.position = Vector2(gap[0] - 14, gap[2] - 8)
			player.velocity = Vector2.ZERO
			await wait(0.12)
			Input.action_press("right")
			player.velocity.x = player.speed
			Input.action_press("jump")
			await wait(1.0)
			Input.action_release("jump")
			Input.action_release("right")
			await wait(0.1)
			check(player.position.x > gap[1] and player.is_on_floor(), "Phase %d gap %d crossed at new speed" % [phase,gap[0]])
		# Test the tallest pipe in this scene, with normal collision.
		var pipes = get_tree().current_scene.get_node("Environment/Pipes").get_children()
		var pipe = pipes[0]
		for candidate in pipes:
			if candidate.position.y < pipe.position.y:
				pipe = candidate
		player.position = Vector2(pipe.position.x - 44, 72)
		player.velocity = Vector2.ZERO
		await wait(0.3)
		Input.action_press("right")
		player.velocity.x = player.speed
		Input.action_press("jump")
		await wait(1.35)
		Input.action_release("jump")
		Input.action_release("right")
		await wait(0.1)
		check(player.position.x > pipe.position.x + 24 and player.is_on_floor(), "Phase %d highest pipe cleared" % phase)
	var manager = get_tree().get_first_node_in_group("level_manager")
	var player = manager.player
	player.position = Vector2(-150,72)
	player.velocity = Vector2.ZERO
	player.fire_cooldown = 0
	player.animated_sprite_2d.scale.x = 1
	var enemy = load("res://Scenes/goomba.tscn").instantiate()
	enemy.position = Vector2(-105,72)
	get_tree().current_scene.add_child(enemy)
	player.shoot()
	await wait(0.3)
	check(enemy.defeated, "Fireball defeats Goomba")
	check(manager.points >= 100, "Fireball awards score")
	player.player_mode = Player.PlayerMode.BIG
	player.position.y = 400
	await wait(2)
	manager = get_tree().get_first_node_in_group("level_manager")
	check(manager.phase == 4 and not manager.player.is_dead, "Fall restarts correct phase")
	print("FAILURES: %d" % failures)
	get_tree().quit(1 if failures else 0)
